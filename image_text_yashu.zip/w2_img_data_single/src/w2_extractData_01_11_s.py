from pdf2image import convert_from_path
from src.imageTextExtractor_s import ImageTextExtractor
from PIL import Image
import os,glob
image_block_obj = ImageTextExtractor()

#combinations=employers,employer

#var1="employers name address and zip code"
#var1=    "employer name address and zip code"
var11=   "employer address and zip code"
var12=   "employer name"


#var2=    "employee name address and zip code"
var21=   "employee address and zip code"
var22=   "employee name"


var31=    "employer id number"

var4="wages, tips, other compensation"
var5="social security wages"
var6="medicare wages and tips"
TaxStatementYear=["w-2 wage and tax Statement","w-2 tax and wage Statement"," w-2 and earnings summary","form w-2 statement"]

inputFolderPath="../data/pdfs/"
ConvertedImgsPath="../data/imgs/"

def removePunctuation(data):
    # punctuation marks
    punctuations ='''!()-[]{};:'"\<>./?@#$%^&*_~'''

    # traverse the given string and if any punctuation
    # marks occur replace it with null
    for x in data:
        if x in punctuations:
            data = data.replace(x, "").replace("\\'s","")

            # Print string without punctuation
    return (data.lower().strip())



def FilterData(Datalist,varlist):
    for er in Datalist:
        for var in varlist:
            if var in er:
                Datalist.remove(er)

    Datalist=list(set(Datalist))
    return Datalist

def ConvertPdfToImgs(inputFolderPath):
    filenames = [f for f in os.listdir(inputFolderPath) if os.path.isfile(os.path.join(inputFolderPath, f))]
    for i,eachpdf in enumerate(filenames):
        numberPages = convert_from_path(inputFolderPath+eachpdf)
        foldername, file_extension = os.path.splitext(eachpdf)
        PdfImgFolderPath=ConvertedImgsPath+foldername
        if not os.path.exists(PdfImgFolderPath):
            os.makedirs(PdfImgFolderPath)
        for cnt, page in enumerate(numberPages):
            page.save(PdfImgFolderPath+"/file_" + str(cnt) + ".jpg", "JPEG")
    print(" images converted")


def Extract(ConvertedImgsPath):
    for pdfFolder in os.listdir(ConvertedImgsPath) :
        extracted_data={}
        employerName=[]
        employeeName=[]
        employerId=[]
        WagesTips=[]
        SSwages=[]
        MediWages=[]
        W2Year=[]

        isEmployerNameFound=False
        isEmployeeNameFound=False
        isEmployerIdFound=False


        isWagesFound=False
        isSSWagesFound=False
        isMediWagesFound=False


        for eachImg in glob.glob(str(ConvertedImgsPath+pdfFolder)+"/*.jpg"):
            extracted_data["file"]=pdfFolder
            imagefiles = Image.open(eachImg)
            text_seg = image_block_obj.process_image(imagefiles)
            print(text_seg)
            for varIndex,eachData in enumerate(text_seg):
                eachData=removePunctuation(eachData)

                if (var11 in eachData or var12 in eachData )and (isEmployerNameFound==False) :
                    employerName=employerName+text_seg[varIndex+1:varIndex+4]
                    isEmployerNameFound=True


                if (var21 in eachData or var22 in eachData) and (isEmployeeNameFound==False):
                    employeeName=employeeName+text_seg[varIndex+1:varIndex+4]
                    isEmployeeNameFound=True

                if (var31 in eachData) and (isEmployerIdFound==False):
                    employerId=employerId+text_seg[varIndex+1:varIndex+3]
                    isEmployerIdFound=True

                if var4 in eachData:
                    WagesTips=WagesTips+[text_seg[varIndex+1]]

                if var5 in eachData:
                    SSwages=SSwages+[text_seg[varIndex+1]]

                if var6 in eachData:
                    MediWages=MediWages+[text_seg[varIndex+1]]
                for eachW2year in TaxStatementYear:
                    if eachW2year in eachData:
                        W2Year = W2Year + [text_seg[varIndex]]

        extracted_data[var11]=FilterData(employerName,[var11,var12])
        extracted_data[var21]=FilterData(employeeName,[var21,var22])
        extracted_data[var31]=FilterData(employerId,[var31])
        extracted_data[var4]=FilterData(WagesTips,[var4])
        extracted_data[var5]=FilterData(SSwages,[var5])
        extracted_data[var6]=FilterData(MediWages,[var6])
        extracted_data["year"]=MediWages


        print(extracted_data)

                # if var1 in eachData:
                #     extracted_data["file"] = eachImg
                #     employerName.append(text_seg[varIndex:varIndex + 2])
                # if var2 in eachData :
                #     print(pdfFolder)
                #     print(var2)
                #     print(text_seg[varIndex+1])

            # for idx,eachDataBlock in enumerate(text_seg):
            #     if var1 in eachDataBlock:
            #         print(var1)
            #         print(text_seg[idx+1])
            #         print(text_seg[idx+2])
            #         print(text_seg[idx+3])



# ConvertPdfToImgs(inputFolderPath)
Extract(ConvertedImgsPath)





